/**
 * Glamora Hero Slider Logic
 */
document.addEventListener('DOMContentLoaded', () => {
  const dots = document.querySelectorAll('.glamora-hero__dot');
  if (!dots.length) return;

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      dots.forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
    });
  });
});
