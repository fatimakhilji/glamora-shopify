/**
 * Glamora Flash Deals Countdown Timer
 */
document.addEventListener('DOMContentLoaded', () => {
  const hoursEl = document.getElementById('glamora-timer-hours');
  const minutesEl = document.getElementById('glamora-timer-minutes');
  const secondsEl = document.getElementById('glamora-timer-seconds');

  if (!hoursEl || !minutesEl || !secondsEl) return;

  let totalSeconds = (2 * 3600) + (14 * 60) + 36;

  setInterval(() => {
    if (totalSeconds <= 0) {
      totalSeconds = 86400; // Reset 24 hours
    } else {
      totalSeconds--;
    }

    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;

    hoursEl.textContent = String(h).padStart(2, '0');
    minutesEl.textContent = String(m).padStart(2, '0');
    secondsEl.textContent = String(s).padStart(2, '0');
  }, 1000);
});
