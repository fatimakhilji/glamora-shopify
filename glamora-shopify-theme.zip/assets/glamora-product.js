/**
 * Glamora Product Detail Interactivity
 */
document.addEventListener('DOMContentLoaded', () => {
  // Gallery Thumbnail Switcher
  const thumbs = document.querySelectorAll('.glamora-gallery__thumb');
  const mainImg = document.querySelector('.glamora-gallery__main img');

  if (thumbs.length && mainImg) {
    thumbs.forEach(thumb => {
      thumb.addEventListener('click', () => {
        thumbs.forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        const newSrc = thumb.querySelector('img').getAttribute('src');
        mainImg.setAttribute('src', newSrc);
      });
    });
  }

  // Variant Swatches
  const swatches = document.querySelectorAll('.glamora-swatch-btn');
  swatches.forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.closest('.glamora-swatches');
      parent.querySelectorAll('.glamora-swatch-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Accordion Panels
  const accordions = document.querySelectorAll('.glamora-accordion__btn');
  accordions.forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = btn.nextElementSibling;
      const isOpen = panel.classList.contains('open');
      
      // Toggle
      if (isOpen) {
        panel.classList.remove('open');
        btn.querySelector('.accordion-icon').textContent = '+';
      } else {
        panel.classList.add('open');
        btn.querySelector('.accordion-icon').textContent = '−';
      }
    });
  });
});
