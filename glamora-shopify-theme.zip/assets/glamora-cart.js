/**
 * Glamora Cart Management
 * Handles Ajax cart actions, quantity updates, removal, and sidebar UI
 */

function quickAddToCart(title, price, image) {
  const cartItemsContainer = document.querySelector('.glamora-cart-card__items');
  if (!cartItemsContainer) return;

  // Check if item already in cart
  const existingItem = Array.from(cartItemsContainer.querySelectorAll('.glamora-cart-item')).find(el => {
    const elTitle = el.querySelector('.glamora-cart-item__title');
    return elTitle && elTitle.textContent.trim() === title.trim();
  });

  if (existingItem) {
    const qtyVal = existingItem.querySelector('.glamora-qty-val');
    if (qtyVal) {
      qtyVal.textContent = parseInt(qtyVal.textContent) + 1;
    }
  } else {
    const newItemHTML = `
      <div class="glamora-cart-item" data-price="${price}">
        <div class="glamora-cart-item__image">
          <img src="${image || 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=120'}" alt="${title}" width="60" height="60">
        </div>
        <div class="glamora-cart-item__details">
          <div class="glamora-cart-item__header">
            <h4 class="glamora-cart-item__title">${title}</h4>
            <button type="button" class="glamora-cart-item__remove" onclick="removeCartItem(this)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
          <p class="glamora-cart-item__variant">Standard</p>
          <div class="glamora-cart-item__footer">
            <div class="glamora-quantity-stepper">
              <button type="button" class="glamora-qty-btn minus" onclick="changeItemQty(this, -1)">-</button>
              <span class="glamora-qty-val">1</span>
              <button type="button" class="glamora-qty-btn plus" onclick="changeItemQty(this, 1)">+</button>
            </div>
            <div class="glamora-cart-item__price">${price}</div>
          </div>
        </div>
      </div>
    `;
    cartItemsContainer.insertAdjacentHTML('beforeend', newItemHTML);
  }

  updateCartTotals();
  showToast(`${title} added to cart!`);
}

function changeItemQty(btn, change) {
  const row = btn.closest('.glamora-cart-item');
  const valEl = row.querySelector('.glamora-qty-val');
  let currentVal = parseInt(valEl.textContent);
  currentVal += change;

  if (currentVal <= 0) {
    row.remove();
  } else {
    valEl.textContent = currentVal;
  }
  updateCartTotals();
}

function removeCartItem(btn) {
  const row = btn.closest('.glamora-cart-item');
  if (row) {
    row.style.opacity = '0';
    setTimeout(() => {
      row.remove();
      updateCartTotals();
    }, 200);
  }
}

function updateCartTotals() {
  const rows = document.querySelectorAll('.glamora-cart-item');
  let totalCount = 0;
  let subtotal = 0;

  rows.forEach(row => {
    const qty = parseInt(row.querySelector('.glamora-qty-val')?.textContent || '1');
    totalCount += qty;

    const priceText = row.querySelector('.glamora-cart-item__price')?.textContent || '0';
    const num = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
    subtotal += (num * qty);
  });

  // Update Cart Header count: "Your Cart (X)"
  const titleCount = document.querySelector('.glamora-cart-card__title');
  if (titleCount) {
    titleCount.textContent = `Your Cart (${totalCount})`;
  }

  // Update Header Cart Badge
  const headerBadge = document.querySelector('.glamora-cart-badge');
  if (headerBadge) {
    headerBadge.textContent = totalCount;
  }

  // Update Subtotal display
  const subtotalEl = document.querySelector('.subtotal-amount');
  if (subtotalEl) {
    subtotalEl.textContent = `Rs. ${subtotal.toLocaleString()}`;
  }
}

function toggleWishlist(btn) {
  btn.classList.toggle('active');
  const svg = btn.querySelector('svg');
  if (btn.classList.contains('active')) {
    svg.setAttribute('fill', '#E84E75');
    svg.setAttribute('stroke', '#E84E75');
  } else {
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', '#999999');
  }
}

function showToast(message) {
  let toast = document.getElementById('glamora-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'glamora-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #1E1E1E;
      color: #FFFFFF;
      padding: 12px 20px;
      border-radius: 50px;
      font-size: 13px;
      font-weight: 500;
      z-index: 9999;
      box-shadow: 0 8px 24px rgba(0,0,0,0.2);
      transition: all 0.3s ease;
      opacity: 0;
      transform: translateY(10px);
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.style.opacity = '1';
  toast.style.transform = 'translateY(0)';
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
  }, 2500);
}
